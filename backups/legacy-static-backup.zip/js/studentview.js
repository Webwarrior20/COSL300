import { sb } from "./supabase.js";

const params = new URLSearchParams(location.search);
const code = params.get("code") || localStorage.getItem("GAME_CODE");

const codeLine = document.getElementById("codeLine");
const catRow = document.getElementById("catRow");
const board = document.getElementById("board");
const msg = document.getElementById("msg");

// Overlay / task modal
const overlay = document.getElementById("overlay");
const taskMeta = document.getElementById("taskMeta");
const taskTitle = document.getElementById("taskTitle");
const taskText = document.getElementById("taskText");
const taskBtns = document.getElementById("taskBtns");
const taskMsg = document.getElementById("taskMsg");
const closeTaskBtn = document.getElementById("closeTaskBtn");

let game = null;
let state = null;
let player = null;

let chBoard = null;
let pollTimer = null;

const VALUES = [100, 200, 300, 400, 500];

const ROUND_DEFS = {
  1: {
    cats: ["Fitness","Movement","Safe & Respectful","Nutrition","Smart Money"],
    tasks: {
      "Fitness": {100:"List 2 endurance activities.",200:"What’s a warm-up? Name 2 warm-ups.",300:"Name 3 parts of fitness.",400:"Plan 10 min activity after school.",500:"Explain 2 benefits of daily activity."},
      "Movement": {100:"Safe landing when jumping?",200:"Name 2 movement skills.",300:"How does teamwork help? (2)",400:"Write 3 fair play rules.",500:"How can you include someone left out?"},
      "Safe & Respectful": {100:"What is bully-free? 1 example.",200:"2 safe responses to teasing.",300:"3 respectful behaviors.",400:"1 healthy goal + 2 steps.",500:"Help a friend being excluded (3 steps)."},
      "Nutrition": {100:"2 healthy snacks + why.",200:"Balanced meal = ? 3 food groups.",300:"2 credible nutrition sources.",400:"Plan a balanced lunch.",500:"2 better drink options than sugary drinks."},
      "Smart Money": {100:"Need vs want example.",200:"2 factors before buying.",300:"Split $10: save/spend/share.",400:"What is a budget?",500:"Smart decision scenario + why."}
    }
  },
  2: {
    cats: ["Waste & Impact","Gravity & Magnetism","Earth Systems","Organisms","Space & Design"],
    tasks: {
      "Waste & Impact": {100:"2 recyclable + 1 non-recyclable.",200:"What is compost? 2 examples.",300:"2 impacts of too much garbage.",400:"3 ways school can reduce waste.",500:"Explain 3Rs with examples."},
      "Gravity & Magnetism": {100:"What is gravity?",200:"2 magnetic objects.",300:"Explain non-contact force.",400:"How to test magnetism?",500:"2 examples of gravity in sports/play."},
      "Earth Systems": {100:"Name land/air/water/organisms.",200:"How plants help air?",300:"2 connections among systems.",400:"3 conservation actions.",500:"Explain a simple food chain."},
      "Organisms": {100:"3 senses + body parts.",200:"How teeth help survival?",300:"2 structures + functions for an animal.",400:"Bird vs fish adaptation.",500:"Design a habitat helper idea."},
      "Space & Design": {100:"1 way Sun affects life.",200:"Why day/night?",300:"2 space tools.",400:"Design steps (ask→improve).",500:"Mini experiment: what data & why?"}
    }
  }
};

function setMsg(t){ msg.textContent = t || ""; }
function showOverlay(on){ overlay.style.display = on ? "flex" : "none"; }

function parseKey(key){
  const [r, cat, v] = String(key).split("|");
  return { round: Number(r?.replace("R","")) || 1, cat, value: Number(v) || 100 };
}
function getTask(key){
  const { round, cat, value } = parseKey(key);
  const text = ROUND_DEFS?.[round]?.tasks?.[cat]?.[value] || "Task coming soon.";
  return { title: `${cat} • ${value} pts`, text };
}

async function loadGame(){
  const { data, error } = await sb.from("games").select("*").eq("code", code).maybeSingle();
  if (error) console.log("loadGame", error);
  return data || null;
}
async function loadState(){
  const { data, error } = await sb.from("board_state").select("*").eq("game_id", game.id).maybeSingle();
  if (error) console.log("loadState", error);
  return data || null;
}
async function loadPlayer(){
  const pid = localStorage.getItem("PLAYER_ID");
  if (!pid) return null;

  const { data, error } = await sb.from("players").select("*").eq("id", pid).maybeSingle();
  if (error) console.log("loadPlayer", error);
  return data || null;
}

function renderCats(){
  const def = ROUND_DEFS[game.round] || ROUND_DEFS[1];
  catRow.innerHTML = "";
  def.cats.forEach(c=>{
    const d = document.createElement("div");
    d.className = "cat";
    d.textContent = c;
    catRow.appendChild(d);
  });
}

function renderBoard(){
  const def = ROUND_DEFS[game.round] || ROUND_DEFS[1];
  const opened = new Set(state?.opened || []);

  board.innerHTML = "";
  VALUES.forEach(v=>{
    def.cats.forEach(cat=>{
      const key = `R${game.round}|${cat}|${v}`;
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.textContent = v;

      if (opened.has(key)) cell.classList.add("opened");

      // Students cannot click / request / anything
      cell.style.pointerEvents = "none";
      cell.classList.add("disabled");

      board.appendChild(cell);
    });
  });
}

/**
 * ✅ Student task view:
 * opens whenever board_state.current_task changes to non-null
 */
function openTaskFromBroadcast(taskKey){
  const t = getTask(taskKey);

  taskMeta.textContent = taskKey;
  taskTitle.textContent = t.title;
  taskText.textContent = t.text;

  taskMsg.textContent = "Teacher is showing this to the whole class ✅";
  taskBtns.innerHTML = ""; // view only

  const closeBtn = document.createElement("button");
  closeBtn.className = "tbtn tbtnGhost";
  closeBtn.textContent = "Close";
  closeBtn.onclick = () => showOverlay(false);

  taskBtns.appendChild(closeBtn);
  showOverlay(true);
}

function closeIfTeacherClears(){
  // If teacher clears current_task, close modal automatically
  showOverlay(false);
}

closeTaskBtn.onclick = () => showOverlay(false);

async function subscribeBoard(){
  try { if (chBoard) await sb.removeChannel(chBoard); } catch {}

  chBoard = sb.channel(`board-${game.id}-student`)
    .on(
      "postgres_changes",
      { event:"*", schema:"public", table:"board_state", filter:`game_id=eq.${game.id}` },
      (p)=>{
        state = p.new;

        renderBoard();

        const taskKey = state?.current_task;
        if (taskKey) openTaskFromBroadcast(taskKey);
        else closeIfTeacherClears();
      }
    )
    .subscribe();

  // Fallback polling (in case realtime is flaky)
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    const s = await loadState();
    if (!s) return;

    const prev = state?.current_task;
    state = s;
    renderBoard();

    const now = state?.current_task;

    if (now && now !== prev) openTaskFromBroadcast(now);
    if (!now && prev) closeIfTeacherClears();
  }, 900);
}

(async function boot(){
  if (!code) return setMsg("Missing game code.");
  codeLine.textContent = `Code: ${code}`;
  setMsg("Loading…");

  game = await loadGame();
  if (!game) return setMsg("Game not found.");

  player = await loadPlayer();
  if (!player) {
    // This keeps it simple: if they opened studentview directly, tell them to re-join
    return setMsg("Missing player info. Please join again from join page.");
  }

  state = await loadState();
  if (!state) return setMsg("Board state missing.");

  renderCats();
  renderBoard();

  // If teacher already showing something, open immediately
  if (state?.current_task) openTaskFromBroadcast(state.current_task);

  await subscribeBoard();

  setMsg("Waiting for teacher…");
})();
