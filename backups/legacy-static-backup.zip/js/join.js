import { sb } from "./supabase.js";

const nameEl = document.getElementById("name");
const studentIdEl = document.getElementById("studentId");
const codeEl = document.getElementById("code");
const joinBtn = document.getElementById("joinBtn");
const msg = document.getElementById("msg");
const wait = document.getElementById("wait");

const LS_PLAYER_ID = "PLAYER_ID";
const LS_GAME_CODE = "GAME_CODE";
const LS_STUDENT_ID = "STUDENT_ID";

let statusChannel = null;
let pollTimer = null;

function setMsg(t){ msg.textContent = t || ""; }

function normCode(x){
  return (x || "").trim().replace(/\s+/g,"").slice(0,6);
}

function normStudentId(x){
  return (x || "").trim().replace(/\s+/g,"");
}

async function getGameByCode(code){
  const { data, error } = await sb
    .from("games")
    .select("id,code,status,round")
    .eq("code", code)
    .maybeSingle();
  if (error) console.log("getGameByCode", error);
  return data || null;
}

function goStudentView(code){
  localStorage.setItem(LS_GAME_CODE, code);
  location.href = `./game.html?code=${encodeURIComponent(code)}&role=student`;
}

async function subscribeToStart(gameId, code){
  try { if (statusChannel) await sb.removeChannel(statusChannel); } catch {}

  statusChannel = sb.channel(`game-status-${gameId}`)
    .on(
      "postgres_changes",
      { event:"UPDATE", schema:"public", table:"games", filter:`id=eq.${gameId}` },
      (p)=>{
        const g = p.new;
        if (g?.status === "started") goStudentView(code);
      }
    )
    .subscribe();

  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    const g = await getGameByCode(code);
    if (g?.status === "started") goStudentView(code);
  }, 1000);
}

async function findExistingPlayer(gameId, student_id){
  // Find by game + student_id first (strongest link)
  const { data, error } = await sb
    .from("players")
    .select("id,name,student_id")
    .eq("game_id", gameId)
    .eq("student_id", student_id)
    .maybeSingle();

  if (error) console.log("findExistingPlayer", error);
  return data || null;
}

async function createPlayer(gameId, name, student_id){
  const { data: player, error } = await sb
    .from("players")
    .insert([{
      game_id: gameId,
      name,
      student_id,
      score: 0,
      tasks_completed: 0,
      joined_at: new Date().toISOString()
    }])
    .select("id,student_id")
    .single();

  if (error) {
    console.log("createPlayer", error);
    return null;
  }
  return player || null;
}

async function updateNameIfNeeded(playerId, name){
  // Optional: keep latest name if student changes it
  const { error } = await sb
    .from("players")
    .update({ name })
    .eq("id", playerId);

  if (error) console.log("updateNameIfNeeded", error);
}

joinBtn.onclick = async () => {
  setMsg("");
  wait.style.display = "none";

  const name = (nameEl.value || "").trim();
  const student_id = normStudentId(studentIdEl.value);
  const code = normCode(codeEl.value);

  if (!name) return setMsg("Enter your name.");
  if (!student_id) return setMsg("Enter your Student ID.");
  if (code.length !== 6) return setMsg("Enter a 6-digit game code.");

  joinBtn.disabled = true;
  setMsg("Joining...");

  const game = await getGameByCode(code);
  if (!game) {
    joinBtn.disabled = false;
    return setMsg("Game not found. Check the code.");
  }

  // 1) Reuse existing player row if same student_id already joined this game
  let player = await findExistingPlayer(game.id, student_id);

  // 2) If none exists, create it
  if (!player) {
    player = await createPlayer(game.id, name, student_id);
    if (!player) {
      joinBtn.disabled = false;
      return setMsg("Could not join (table/RLS/columns).");
    }
  } else {
    // keep name updated (optional)
    await updateNameIfNeeded(player.id, name);
  }

  localStorage.setItem(LS_PLAYER_ID, player.id);
  localStorage.setItem(LS_GAME_CODE, code);
  localStorage.setItem(LS_STUDENT_ID, student_id);

  // If teacher already started, jump in
  if (game.status === "started") {
    return goStudentView(code);
  }

  setMsg("");
  wait.style.display = "block";
  await subscribeToStart(game.id, code);
};

window.addEventListener("beforeunload", () => {
  if (pollTimer) clearInterval(pollTimer);
});
