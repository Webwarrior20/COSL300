import { sb } from "./supabase.js";

const params = new URLSearchParams(location.search);
const code = params.get("code") || localStorage.getItem("GAME_CODE");
const role = params.get("role") || "student";

const whoLine = document.getElementById("whoLine");
const codeLine = document.getElementById("codeLine");
const roundTitle = document.getElementById("roundTitle");
const subTitle = document.getElementById("subTitle");
const catRow = document.getElementById("catRow");
const board = document.getElementById("board");
const msg = document.getElementById("msg");

const plist = document.getElementById("plist");
const countEl = document.getElementById("count");
const nextRoundBtn = document.getElementById("nextRoundBtn");

const overlay = document.getElementById("overlay");
const taskMeta = document.getElementById("taskMeta");
const taskTitle = document.getElementById("taskTitle");
const taskText = document.getElementById("taskText");
const taskBtns = document.getElementById("taskBtns");
const taskMsg = document.getElementById("taskMsg");
const closeTaskBtn = document.getElementById("closeTaskBtn");
const assignTo = document.getElementById("assignTo");
const teacherPanel = document.getElementById("teacherPanel");
const studentPanel = document.getElementById("studentPanel");
const treeStage = document.getElementById("treeStage");
const treePoints = document.getElementById("treePoints");
const treeLevel = document.getElementById("treeLevel");
const progressFill = document.getElementById("progressFill");
const studentIdLine = document.getElementById("studentIdLine");

let game = null;
let state = null;
let players = [];
let me = null;

let chBoard = null;
let chGame = null;
let chPlayers = null;
let chAssign = null;

let pollTimer = null;
let dismissedTaskKey = null;
let activeModalTaskKey = null;

const VALUES = [100,200,300,400,500];

// Two rounds only (Grade 4)
const ROUND_CONFIG = {
  1: {
    title: "Round 1 — Phys Ed • Health • Wellness",
    cats: ["Fitness","Movement","Safe & Respectful","Nutrition","Smart Money"]
  },
  2: {
    title: "Round 2 — Science",
    cats: ["Waste & Impact","Forces","Earth Systems","Organisms","Space & Design"]
  }
};

// Sample tasks for now (you’ll replace later with your real packs)
const TASKS = {
  // Round 1
  "Fitness": {
    100: "Do 30 seconds of marching in place. Name 1 thing your body feels.",
    200: "Show a safe warm-up stretch (arms/neck/shoulders). Why warm up?",
    300: "Explain what “heart rate” means in simple words.",
    400: "Create a 3-step mini workout (e.g., jump, squat, stretch).",
    500: "What are 2 ways exercise helps your brain and mood?"
  },
  "Movement": {
    100: "Show 1 balance move (stand on one foot).",
    200: "Combine 3 movements: hop + turn + reach.",
    300: "Explain why body control matters in sports.",
    400: "Create a short movement pattern and teach it to a partner.",
    500: "Name 3 safety rules for active play."
  },
  "Safe & Respectful": {
    100: "Give 1 example of respectful behaviour in class.",
    200: "What can you do if someone is being left out?",
    300: "What is consent (in simple terms) about belongings/personal space?",
    400: "Give 2 ways to respond to bullying safely (tell/trusted adult, walk away, etc.).",
    500: "Set a goal: one kind/respectful action you’ll do today + how."
  },
  "Nutrition": {
    100: "Name 1 healthy snack and why it’s healthy.",
    200: "What does “balanced meal” mean? Give an example.",
    300: "Where can you find credible nutrition info (parent, teacher, health site, label)?",
    400: "Plan a balanced lunch (list items).",
    500: "Explain why water matters for your body."
  },
  "Smart Money": {
    100: "Name 1 thing you *need* and 1 thing you *want*.",
    200: "If you have $10, what factors help you decide what to buy?",
    300: "Explain saving in one sentence.",
    400: "Make a simple plan: save / spend / share (percentages or amounts).",
    500: "Give 2 reasons to think before buying."
  },

  // Round 2 (Science)
  "Waste & Impact": {
    100: "Name 1 thing that can be recycled and 1 that cannot.",
    200: "What happens if too much waste goes to landfill?",
    300: "Suggest 2 ways to reduce waste at school.",
    400: "Explain compost in simple words.",
    500: "Describe one environmental impact of waste and one solution."
  },
  "Forces": {
    100: "What is gravity?",
    200: "Name one thing that is magnetic.",
    300: "Explain ‘non-contact force’ with an example.",
    400: "Why do magnets attract some metals but not others (simple)?",
    500: "Design a quick test to check if an object is magnetic."
  },
  "Earth Systems": {
    100: "Name the Earth systems: land, air, water, organisms.",
    200: "How can pollution affect water and organisms?",
    300: "Give 2 conservation actions people can do.",
    400: "Explain how plants and animals depend on water/air.",
    500: "Describe one connection between land and water systems."
  },
  "Organisms": {
    100: "Name one sensory organ and its job.",
    200: "How does fur/feathers help an animal?",
    300: "Name 2 external structures and their functions.",
    400: "How do eyes/ears help animals survive?",
    500: "Compare 2 organisms: one structure + what it helps them do."
  },
  "Space & Design": {
    100: "Name one object in space we see from Earth.",
    200: "How is space connected to daily life (satellites, weather, GPS)?",
    300: "What is a ‘design process’ in simple steps?",
    400: "Give a problem and a simple design solution.",
    500: "Why do we use data and evidence in science?"
  }
};

function setMsg(t){ msg.textContent = t || ""; }
function showOverlay(on){ overlay.style.display = on ? "flex" : "none"; }

function cfg(){
  return ROUND_CONFIG[game?.round || 1] || ROUND_CONFIG[1];
}

function cats(){
  return cfg().cats;
}

function taskKey(cat, value){
  return `R${game.round}|${cat}|${value}`;
}

function parseKey(k){
  const [r, cat, v] = String(k).split("|");
  return { round: Number(r?.replace("R","")) || 1, cat, value: Number(v)||100 };
}

function getTaskText(k){
  const { cat, value } = parseKey(k);
  return TASKS?.[cat]?.[value] || "Task placeholder (replace later).";
}

function renderCats(){
  catRow.innerHTML = "";
  cats().forEach(c=>{
    const d = document.createElement("div");
    d.className = "cat";
    d.textContent = c;
    catRow.appendChild(d);
  });
}

function renderBoard(){
  board.innerHTML = "";
  const opened = new Set(state?.opened || []);

  VALUES.forEach(v=>{
    cats().forEach(cat=>{
      const k = taskKey(cat, v);
      const cell = document.createElement("div");
      cell.className = "cell";
      cell.textContent = v;

      if (opened.has(k)) cell.classList.add("opened");

      // Students cannot click tiles
      if (role !== "teacher") {
        cell.classList.add("disabled");
      }

      cell.onclick = () => {
        if (role !== "teacher") return;
        if (opened.has(k)) return;
        openTeacherModal(k);
      };

      board.appendChild(cell);
    });
  });
}

function renderPlayers(){
  plist.innerHTML = "";
  countEl.textContent = String(players.length);

  if (!players.length) {
    plist.innerHTML = `<div class="muted">No students yet.</div>`;
    return;
  }

  // Sort by score desc
  const sorted = [...players].sort((a,b)=> (b.score||0) - (a.score||0));

  for (const p of sorted) {
    const row = document.createElement("div");
    row.className = "pRow";
    row.innerHTML = `
      <div>
        <div>${p.name}</div>
        <div class="pillMini">ID: ${p.student_id || "—"}</div>
      </div>
      <div>⭐ ${p.score ?? 0}</div>
    `;
    plist.appendChild(row);
  }
}

function openTeacherModal(k){
  activeModalTaskKey = k;
  const { cat, value } = parseKey(k);

  taskMeta.textContent = `Round ${game.round} • ${cat} • ${value}`;
  taskTitle.textContent = `${cat} — ${value} pts`;
  taskText.textContent = getTaskText(k);
  taskMsg.textContent = "";

  // teacher sees multi-select list
  assignTo.style.display = "block";
  assignTo.innerHTML = "";

  for (const p of players) {
    const opt = document.createElement("option");
    opt.value = p.id;
    opt.textContent = `${p.name} (ID: ${p.student_id || "—"})`;
    assignTo.appendChild(opt);
  }

  assignTo.onchange = () => {
    const selected = Array.from(assignTo.selectedOptions);
    if (selected.length > 5) {
      selected[selected.length - 1].selected = false;
      taskMsg.textContent = "You can select up to 5 students.";
    }
  };

  taskBtns.innerHTML = "";

  const showAllBtn = document.createElement("button");
  showAllBtn.className = "tbtn tbtnPrimary";
  showAllBtn.textContent = "Show to ALL";
  showAllBtn.onclick = async () => {
    if (!players.length) { taskMsg.textContent = "No students joined yet."; return; }
    taskMsg.textContent = "Showing to all...";

    const rows = players.map(p => ({
      game_id: game.id,
      task_key: k,
      player_id: p.id
    }));

    const { error } = await sb.from("task_assignments").insert(rows);
    if (error) {
      console.log(error);
      taskMsg.textContent = "Show failed (check table/RLS).";
      return;
    }

    const opened = [...(state?.opened || [])];
    if (!opened.includes(k)) opened.push(k);

    await sb.from("board_state").update({
      opened,
      current_task: k,
      phase: "task",
      updated_at: new Date().toISOString()
    }).eq("game_id", game.id);

    state = { ...(state||{}), opened, current_task: k, phase: "task" };
    renderBoard();

    taskMsg.textContent = "Showing to all ✅";
    renderTeacherCloseButtons(k);
  };

  const assignBtn = document.createElement("button");
  assignBtn.className = "tbtn tbtnPrimary";
  assignBtn.textContent = "Assign to Selected";
  assignBtn.onclick = async () => {
    if (!players.length) { taskMsg.textContent = "No students joined yet."; return; }

    const selected = Array.from(assignTo.selectedOptions).map(o => o.value);
    if (!selected.length) {
      taskMsg.textContent = "Select at least one student.";
      return;
    }
    if (selected.length > 5) {
      taskMsg.textContent = "Select up to 5 students.";
      return;
    }

    taskMsg.textContent = "Assigning...";
    const rows = selected.map(pid => ({
      game_id: game.id,
      task_key: k,
      player_id: pid
    }));

    const { error } = await sb.from("task_assignments").insert(rows);
    if (error) {
      console.log(error);
      taskMsg.textContent = "Assign failed (check table/RLS).";
      return;
    }

    const opened = [...(state?.opened || [])];
    if (!opened.includes(k)) opened.push(k);

    await sb.from("board_state").update({
      opened,
      current_task: k,
      phase: "task",
      updated_at: new Date().toISOString()
    }).eq("game_id", game.id);

    state = { ...(state||{}), opened, current_task: k, phase: "task" };
    renderBoard();

    taskMsg.textContent = "Assigned ✅";
    renderTeacherCloseButtons(k);
  };

  const closeBtn = document.createElement("button");
  closeBtn.className = "tbtn tbtnGhost";
  closeBtn.textContent = "Close";
  closeBtn.onclick = () => showOverlay(false);

  taskBtns.appendChild(showAllBtn);
  taskBtns.appendChild(assignBtn);
  taskBtns.appendChild(closeBtn);

  showOverlay(true);
}

function openStudentTask(k){
  activeModalTaskKey = k;
  dismissedTaskKey = null;
  const { cat, value } = parseKey(k);

  taskMeta.textContent = `Round ${game.round} • ${cat} • ${value}`;
  taskTitle.textContent = `${cat} — ${value} pts`;
  taskText.textContent = getTaskText(k);

  // student view-only
  assignTo.style.display = "none";
  taskBtns.innerHTML = "";
  taskMsg.textContent = "Do the activity now ✅";

  const closeBtn = document.createElement("button");
  closeBtn.className = "tbtn tbtnGhost";
  closeBtn.textContent = "Close";
  closeBtn.onclick = () => {
    dismissedTaskKey = k;
    showOverlay(false);
  };

  taskBtns.appendChild(closeBtn);

  showOverlay(true);
}

closeTaskBtn.onclick = async () => {
  if (role === "teacher" && state?.current_task) {
    await closeTask(false);
  } else {
    if (activeModalTaskKey) dismissedTaskKey = activeModalTaskKey;
    showOverlay(false);
  }
};

// ---------- Data loads ----------
async function loadGame(){
  const { data, error } = await sb
    .from("games")
    .select("id,code,status,round")
    .eq("code", code)
    .maybeSingle();

  if (error) console.log(error);
  return data || null;
}

async function loadState(){
  const { data, error } = await sb
    .from("board_state")
    .select("*")
    .eq("game_id", game.id)
    .maybeSingle();

  if (error) console.log(error);
  return data || null;
}

async function loadPlayers(){
  const { data, error } = await sb
    .from("players")
    .select("id,name,student_id,score,joined_at")
    .eq("game_id", game.id)
    .order("joined_at", { ascending: true });

  if (error) console.log(error);
  return data || [];
}

// ---------- Realtime (with polling fallback) ----------
async function subscribe(){
  // board_state
  if (chBoard) { try{ await sb.removeChannel(chBoard);}catch{} }
  chBoard = sb.channel(`board-${game.id}`)
    .on("postgres_changes",
      { event:"*", schema:"public", table:"board_state", filter:`game_id=eq.${game.id}` },
      (p)=>{
        state = p.new;
        renderBoard();

        // If teacher opened a task, students see it when assignment arrives (below)
        // Also show “waiting” when not started:
        renderHeader();

        if (role === "student") {
          const taskKey = state?.current_task;
          if (taskKey && taskKey !== dismissedTaskKey) openStudentTask(taskKey);
          else if (!taskKey) {
            dismissedTaskKey = null;
            showOverlay(false);
          }
        }
      }
    )
    .subscribe();

  // game updates (round changes, started status)
  if (chGame) { try{ await sb.removeChannel(chGame);}catch{} }
  chGame = sb.channel(`game-${game.id}`)
    .on("postgres_changes",
      { event:"*", schema:"public", table:"games", filter:`id=eq.${game.id}` },
      (p)=>{
        game = p.new;
        renderAll();
      }
    )
    .subscribe();

  // players updates (teacher wants no refresh)
  if (chPlayers) { try{ await sb.removeChannel(chPlayers);}catch{} }
  chPlayers = sb.channel(`players-${game.id}`)
    .on("postgres_changes",
      { event:"*", schema:"public", table:"players", filter:`game_id=eq.${game.id}` },
      async ()=>{
        players = await loadPlayers();
        renderPlayers();
      }
    )
    .subscribe();

  // assignments:
  // - teacher sends to one student (player_id = that student)
  // - or to all (player_id = null)
  if (chAssign) { try{ await sb.removeChannel(chAssign);}catch{} }

  if (role === "student") {
    const pid = localStorage.getItem("PLAYER_ID");
    if (!pid) return;

    chAssign = sb.channel(`assign-${pid}`)
      .on("postgres_changes",
        { event:"INSERT", schema:"public", table:"task_assignments" },
        (p)=>{
          const row = p.new;
          if (!row) return;

          // Only show if: broadcast OR assigned to me
          if (row.game_id !== game.id) return;
          if (row.player_id && row.player_id !== pid) return;

          openStudentTask(row.task_key);
        }
      )
      .subscribe();
  }

  // Poll fallback (keeps it working even if realtime is blocked at school)
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = setInterval(async ()=>{
    try{
      const g2 = await loadGame();
      if (g2) game = g2;

      const s2 = await loadState();
      if (s2) state = s2;

      players = await loadPlayers();

      renderAll();

      if (role === "student") {
        const taskKey = state?.current_task;
        if (taskKey && taskKey !== dismissedTaskKey) openStudentTask(taskKey);
        else if (!taskKey) {
          dismissedTaskKey = null;
          showOverlay(false);
        }
      }
    } catch(e){
      console.log("poll error", e);
    }
  }, 1200);
}

function renderHeader(){
  whoLine.textContent = role === "teacher" ? "Teacher View" : "Student View";
  codeLine.textContent = `Code: ${code}`;
  roundTitle.textContent = cfg().title;
  subTitle.textContent = (game?.status === "started")
    ? (role === "teacher"
        ? "Click a tile → Send to ONE student (or ALL)."
        : "Wait for your teacher to send you a challenge.")
    : "Waiting for teacher to start the game…";

  // student tiles always disabled; teacher tiles enabled even if not started (your choice)
  // If you want teacher to only click after start, enforce here.
}

function renderAll(){
  renderHeader();
  renderCats();
  renderBoard();
  renderPlayers();

  if (role === "teacher") {
    nextRoundBtn.style.display = "block";
    if (teacherPanel) teacherPanel.style.display = "block";
    if (studentPanel) studentPanel.style.display = "none";
  } else {
    if (teacherPanel) teacherPanel.style.display = "none";
    if (studentPanel) studentPanel.style.display = "block";
    renderStudentProgress();
  }
}

function renderTeacherCloseButtons(k){
  taskBtns.innerHTML = "";

  const usedBtn = document.createElement("button");
  usedBtn.className = "tbtn tbtnWarn";
  usedBtn.textContent = "Close (mark used)";
  usedBtn.onclick = async () => {
    await closeTask(true, k);
    showOverlay(false);
    setMsg("Task closed ✅");
  };

  const freeBtn = document.createElement("button");
  freeBtn.className = "tbtn tbtnGhost";
  freeBtn.textContent = "Close (do NOT mark used)";
  freeBtn.onclick = async () => {
    await closeTask(false, k);
    showOverlay(false);
    setMsg("Task closed ✅");
  };

  taskBtns.appendChild(usedBtn);
  taskBtns.appendChild(freeBtn);
}

async function closeTask(markUsed, keyOverride){
  const key = keyOverride || state?.current_task || activeModalTaskKey;
  if (!key) return;

  let opened = [...(state?.opened || [])];
  if (markUsed) {
    if (!opened.includes(key)) opened.push(key);
  } else {
    opened = opened.filter(k => k !== key);
  }

  await sb.from("board_state").update({
    opened,
    current_task: null,
    phase: "board",
    updated_at: new Date().toISOString()
  }).eq("game_id", game.id);

  state = { ...(state||{}), opened, current_task: null, phase: "board" };
  renderBoard();
}

function renderStudentProgress(){
  if (role !== "student") return;
  if (!treeStage || !treePoints || !treeLevel || !progressFill) return;

  const pid = localStorage.getItem("PLAYER_ID");
  const studentId = localStorage.getItem("STUDENT_ID");
  if (studentIdLine) studentIdLine.textContent = `Student ID: ${studentId || "—"}`;

  const meRow = players.find(p => p.id === pid);
  const score = Math.max(0, Math.min(10000, meRow?.score ?? 0));

  const pct = Math.round((score / 10000) * 100);
  progressFill.style.width = `${pct}%`;
  treePoints.textContent = `${score} / 10000`;

  let level = "Seed";
  let emoji = "🌱";
  let scale = 0.7;
  if (score >= 2000) { level = "Sprout"; emoji = "🌿"; scale = 0.9; }
  if (score >= 5000) { level = "Sapling"; emoji = "🌳"; scale = 1.05; }
  if (score >= 8000) { level = "Tree"; emoji = "🌳"; scale = 1.2; }
  if (score >= 10000) { level = "Full Tree"; emoji = "🌳"; scale = 1.35; }

  treeLevel.textContent = level;
  treeStage.textContent = emoji;
  treeStage.style.transform = `translateX(-50%) scale(${scale})`;
}

nextRoundBtn.onclick = async () => {
  if (role !== "teacher") return;
  if (!game) return;

  if ((game.round || 1) >= 2) {
    setMsg("This game has only 2 rounds.");
    return;
  }

  setMsg("Switching to Round 2...");

  // Move to round 2, reset board
  await sb.from("games").update({ round: 2 }).eq("id", game.id);

  await sb.from("board_state").update({
    phase: "board",
    current_task: null,
    opened: [],
    updated_at: new Date().toISOString()
  }).eq("game_id", game.id);

  setMsg("");
};

async function boot(){
  if (!code) {
    setMsg("Missing game code. Re-join.");
    return;
  }

  game = await loadGame();
  if (!game) {
    setMsg("Game not found.");
    return;
  }

  state = await loadState();
  if (!state) {
    setMsg("Board state missing. (Create board_state row for this game.)");
    return;
  }

  players = await loadPlayers();

  if (role === "student") {
    const pid = localStorage.getItem("PLAYER_ID");
    if (!pid) {
      setMsg("Missing player. Re-join.");
      return;
    }
    // optional: load my player row (not required for view-only tasks)
    const { data } = await sb.from("players").select("*").eq("id", pid).maybeSingle();
    me = data || null;
  }

  // Header + render
  renderAll();

  // Start subscriptions
  await subscribe();
}

boot();
